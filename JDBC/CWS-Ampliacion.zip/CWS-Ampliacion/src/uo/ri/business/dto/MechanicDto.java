package uo.ri.business.dto;

public class MechanicDto {

	public Long id;
	public String dni;
	public String name;
	public String surname;

}

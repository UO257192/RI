package uo.ri.business.dto;

public class TrainingHoursRow {

	public String vehicleTypeName;
	public String mechanicFullName;
	public int enrolledHours;

}

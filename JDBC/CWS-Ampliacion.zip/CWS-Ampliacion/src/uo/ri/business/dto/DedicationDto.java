package uo.ri.business.dto;

public class DedicationDto {
	
	public Long id;

	public Long course_id;
	public Long vehicleType_id;
	public int percentage;
}

package uo.ri.business.dto;

import java.util.Date;

public class CertificateDto {

	public Long id;

	public MechanicDto mechanic;
	public VehicleTypeDto vehicleType;
	public Date obtainedAt;

}

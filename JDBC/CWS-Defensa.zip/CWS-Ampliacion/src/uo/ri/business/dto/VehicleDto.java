package uo.ri.business.dto;

public class VehicleDto {
	public Long id;

	public String plate;
	public String make;
	public String model;

	public Long clientId;
	public Long vehicleTypeId;

}

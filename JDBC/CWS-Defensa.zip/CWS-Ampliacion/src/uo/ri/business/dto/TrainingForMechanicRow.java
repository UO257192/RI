package uo.ri.business.dto;

public class TrainingForMechanicRow {

	public String vehicleTypeName;
	public int enrolledHours;
	public int attendedHours;

}

package uo.ri.business.dto;

public class VehicleTypeDto {

	public Long id;

	public String name;
	public double pricePerHour;
	public int minTrainigHours;

}

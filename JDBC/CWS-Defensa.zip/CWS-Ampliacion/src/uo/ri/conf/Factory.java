package uo.ri.conf;

public class Factory {
	public static PersistanceFactory persistance = new PersistanceFactory();
	public static ServiceFactory service = new ServiceFactory();
}

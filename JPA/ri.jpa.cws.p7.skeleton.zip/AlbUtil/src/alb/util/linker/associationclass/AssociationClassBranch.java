package alb.util.linker.associationclass;

import alb.util.linker.AssociationSide;

public interface AssociationClassBranch {

	AssociationSide getIdSide();
	AssociationSide getOtherSide();

}

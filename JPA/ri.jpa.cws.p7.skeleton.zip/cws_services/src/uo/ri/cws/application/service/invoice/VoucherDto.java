package uo.ri.cws.application.service.invoice;

public class VoucherDto extends PaymentMeanDto {

	public String code;
	public String description;
	public Double available;

}

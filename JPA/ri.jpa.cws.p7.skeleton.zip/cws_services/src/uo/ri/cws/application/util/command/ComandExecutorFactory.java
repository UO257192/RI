package uo.ri.cws.application.util.command;

public interface ComandExecutorFactory {

	CommandExecutor forExecutor();

}

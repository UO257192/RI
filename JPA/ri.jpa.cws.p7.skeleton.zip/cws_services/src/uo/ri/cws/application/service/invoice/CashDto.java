package uo.ri.cws.application.service.invoice;

public class CashDto extends PaymentMeanDto {

}

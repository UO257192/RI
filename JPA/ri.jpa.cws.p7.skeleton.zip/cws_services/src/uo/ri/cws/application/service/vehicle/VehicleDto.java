package uo.ri.cws.application.service.vehicle;

public class VehicleDto {
	public String id;
	public long version;
	
	public String plate;
	public String make;
	public String model;
	
	public String clientId;
	public String vehicleTypeId;

}

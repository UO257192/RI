package uo.ri.cws.application.repository;

import uo.ri.cws.domain.Client;

public interface ClientRepository extends Repository<Client> {

}

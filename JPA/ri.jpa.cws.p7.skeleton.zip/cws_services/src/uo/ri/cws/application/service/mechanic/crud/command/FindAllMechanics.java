package uo.ri.cws.application.service.mechanic.crud.command;

import java.util.List;

import uo.ri.cws.application.service.mechanic.MechanicDto;
import uo.ri.cws.application.util.command.Command;

public class FindAllMechanics {

	public List<MechanicDto> execute() {
		
		return null;
	}

}

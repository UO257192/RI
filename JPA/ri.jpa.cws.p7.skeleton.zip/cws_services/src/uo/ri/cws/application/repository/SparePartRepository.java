package uo.ri.cws.application.repository;

import uo.ri.cws.domain.SparePart;

public interface SparePartRepository extends Repository<SparePart> {

}

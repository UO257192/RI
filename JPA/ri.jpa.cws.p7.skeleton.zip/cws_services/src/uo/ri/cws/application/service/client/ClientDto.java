package uo.ri.cws.application.service.client;

public class ClientDto {

	public String id;
	public Long version;
	
	public String dni;
	public String name;
	public String surname;
	public String addressStreet;
	public String addressCity;
	public String addressZipcode;
	public String phone;
	public String email;

}

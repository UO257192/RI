package uo.ri.cws.infrastructure.persistence.jpa.repository;

import uo.ri.cws.application.repository.ClientRepository;
import uo.ri.cws.domain.Client;
import uo.ri.cws.infrastructure.persistence.jpa.util.BaseJpaRepository;

public class ClientJpaRepository 
		extends BaseJpaRepository<Client> 
		implements ClientRepository {


}

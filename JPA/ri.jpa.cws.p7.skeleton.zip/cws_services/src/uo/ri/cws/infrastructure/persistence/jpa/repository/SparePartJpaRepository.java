package uo.ri.cws.infrastructure.persistence.jpa.repository;

import uo.ri.cws.application.repository.SparePartRepository;
import uo.ri.cws.domain.SparePart;
import uo.ri.cws.infrastructure.persistence.jpa.util.BaseJpaRepository;

public class SparePartJpaRepository
		extends BaseJpaRepository<SparePart> 
		implements SparePartRepository {

}

package uo.ri.cws.application.service.training;

public class TrainingForMechanicRow {

	public String vehicleTypeName;
	public int enrolledHours;
	public int attendedHours;

}

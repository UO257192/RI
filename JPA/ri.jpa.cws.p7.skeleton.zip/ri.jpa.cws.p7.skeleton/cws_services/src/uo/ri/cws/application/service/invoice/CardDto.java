package uo.ri.cws.application.service.invoice;

import java.util.Date;

public class CardDto extends PaymentMeanDto {
	public String cardNumber;
	public Date cardExpiration;
	public String cardType;

}

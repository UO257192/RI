package uo.ri.cws.application.service.vehicletype;

public class VehicleTypeDto {

	public String id;
	public long version;
	
	public String name;
	public double pricePerHour;
	public int minTrainigHours;
	
}

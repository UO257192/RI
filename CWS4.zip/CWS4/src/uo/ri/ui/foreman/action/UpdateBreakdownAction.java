package uo.ri.ui.foreman.action;

import alb.util.menu.Action;
import uo.ri.common.BusinessException;

public class UpdateBreakdownAction implements Action {

	@Override
	public void execute() throws BusinessException {
		// TODO Auto-generated method stub

	}

}

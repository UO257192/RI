package uo.ri.business.dto;

public class PayrollSummaryDto {
	
	public Long id;
	public String mechanicDni;
	public String mechanicName;
	public String mechanicSurname;
	public double totalGross;
	public double totalDiscount;
	public double totalNet;

}

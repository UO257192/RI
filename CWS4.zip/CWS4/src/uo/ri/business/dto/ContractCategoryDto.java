package uo.ri.business.dto;

public class ContractCategoryDto {

	public Long id;
	public String name;
	public double trieniumSalary;
	public double productivityPlus;
	
}

package uo.ri.business.dto;

public class ContractTypeDto {

	public Long id;
	public String name;
	public int compensationDays;

}
